import mongoose from "mongoose"

const s = new mongoose.Schema({
  title: String,
  desc: String,
  price: Number,
  release_date: String,
  dev_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "developer"
  },
  pub_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "publisher"
  },
  genre_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "genre"
  }
})

export default mongoose.model("game", s)
