import mongoose from "mongoose"


const s = new mongoose.Schema({
  player_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "player"
  },
  game_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "game"
  },
  hours: Number
})

export default mongoose.model("library", s)
