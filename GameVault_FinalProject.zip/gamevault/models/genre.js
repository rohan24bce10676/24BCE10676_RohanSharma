import mongoose from "mongoose"

const s = new mongoose.Schema({
  name: String,
  desc: String
})

export default mongoose.model("genre", s);
