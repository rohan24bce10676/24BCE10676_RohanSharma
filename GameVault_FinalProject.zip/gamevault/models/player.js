import mongoose from "mongoose"

const s = new mongoose.Schema({
  username: String,
  email: String
})

export default mongoose.model("player", s)
