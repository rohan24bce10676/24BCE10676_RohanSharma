import mongoose from "mongoose"

const s = new mongoose.Schema({
  name: String,
  country: String,
  year: Number,
  game_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "game"
  }
})

export default mongoose.model("developer", s)
