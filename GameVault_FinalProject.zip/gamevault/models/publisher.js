import mongoose from "mongoose"

const s = new mongoose.Schema({
  name: String,
  country: String,
  games: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "game"
  }]
})

export default mongoose.model("publisher", s)
