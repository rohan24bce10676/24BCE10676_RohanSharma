import express from "express"
import genre from "../models/genre.js"

const router = express.Router()

router.post("/", async (req, res) => {
  const data = new genre(req.body)
  const result = await data.save()
  res.send(result)
})

router.get("/", async (req, res) => {
  const data = await genre.find()
  res.send(data)
})

router.delete("/:id", async (req, res) => {
  await genre.findByIdAndDelete(req.params.id)
  res.send("deleted")
})

export default router;
