import express from "express"
import developer from "../models/developer.js"

const router = express.Router()

// create developer
router.post("/", async (req, res) => {
  const data = new developer(req.body)
  const result = await data.save()
  res.send(result)
})

// get developers
router.get("/", async (req, res) => {
  const data = await developer.find().populate("game_id")
  res.send(data)
})

// delete developer
router.delete("/:id", async (req, res) => {
  await developer.findByIdAndDelete(req.params.id)
  res.send("deleted")
})

export default router;
