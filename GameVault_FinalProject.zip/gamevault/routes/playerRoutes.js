import express from "express"
import player from "../models/player.js"

const router = express.Router()

// create player
router.post("/", async (req, res) => {
  const data = new player(req.body)
  const result = await data.save()
  res.send(result)
})

// get players
router.get("/", async (req, res) => {
  const data = await player.find()
  res.send(data)
})

// delete player
router.delete("/:id", async (req, res) => {
  await player.findByIdAndDelete(req.params.id)
  res.send("deleted")
})

export default router;
