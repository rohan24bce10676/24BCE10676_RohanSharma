import express from "express"
import publisher from "../models/publisher.js"

const router = express.Router()

// create publisher
router.post("/", async (req, res) => {
  const data = new publisher(req.body)
  const result = await data.save()
  res.send(result)
})

// get all publishers with their games
router.get("/", async (req, res) => {
  const data = await publisher.find().populate("games")
  res.send(data)
})

// delete publisher
router.delete("/:id", async (req, res) => {
  await publisher.findByIdAndDelete(req.params.id)
  res.send("deleted")
})

export default router;
