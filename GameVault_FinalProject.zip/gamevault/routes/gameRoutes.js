import express from "express"
import game from "../models/game.js"
import publisher from "../models/publisher.js"

const router = express.Router()

// create game
router.post("/", async (req, res) => {
  const data = new game(req.body)
  const result = await data.save()

  // add game to publisher
  if (req.body.pub_id) {
    await publisher.findByIdAndUpdate(req.body.pub_id, {
      $push: { games: result._id }
    })
  }

  res.send(result)
})

// get  games
router.get("/", async (req, res) => {
  const data = await game.find().populate("dev_id").populate("pub_id")
  res.send(data)
})

// update game
router.put("/:id", async (req, res) => {
  const data = await game.findByIdAndUpdate(req.params.id, req.body, { new: true })
  res.send(data)
})

// delete game
router.delete("/:id", async (req, res) => {
  await game.findByIdAndDelete(req.params.id)
  res.send("deleted")
})

export default router;
