import express from "express"
import library from "../models/library.js"

const router = express.Router()

// add game to player library 
router.post("/", async (req, res) => {
  const data = new library(req.body)
  const result = await data.save()
  res.send(result)
})

// get all library entries
router.get("/", async (req, res) => {
  const data = await library.find().populate("player_id").populate("game_id")
  res.send(data)
})

// delete library entry
router.delete("/:id", async (req, res) => {
  await library.findByIdAndDelete(req.params.id)
  res.send("deleted")
})

export default router;
