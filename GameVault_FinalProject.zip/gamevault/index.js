import express from "express"
import dotenv from "dotenv"
import connectDB from "./config/db.js"
import gameRoutes from "./routes/gameRoutes.js"
import developerRoutes from "./routes/developerRoutes.js"
import publisherRoutes from "./routes/publisherRoutes.js"
import playerRoutes from "./routes/playerRoutes.js"
import libraryRoutes from "./routes/libraryRoutes.js"
import genreRoutes from "./routes/genreRoutes.js"

dotenv.config()
connectDB()

const app = express()
app.use(express.json())

app.use("/games", gameRoutes)
app.use("/developers", developerRoutes)
app.use("/publishers", publisherRoutes)
app.use("/players", playerRoutes)
app.use("/libraries", libraryRoutes)
app.use("/genres", genreRoutes) 

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
